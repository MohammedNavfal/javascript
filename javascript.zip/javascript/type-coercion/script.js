//type coersion

let a = "25";
let b = 10;
console.log(a + b);

a = Number(a);
console.log(a + b);