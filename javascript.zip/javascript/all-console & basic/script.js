//alert("welcome to js");
console.log("hello");
console.log(123);
console.log(true);
console.log([10, 20, 30, 40]);
console.log({ fnamme: 'navfal', age: 24 });
console.table({ fnamme: 'navfal', age: 24 });
console.error("custom error");
console.warn("custom error");
//console.clear();
console.time("timer");
for (i = 0; i < 10; i++) {
    console.log(i);
}
console.timeEnd("timer");