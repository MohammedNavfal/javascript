//datatype
/*
dynamic program

string
number eg: 1..25,25
boolean eg: true,false
Null
Undefinded
Sysmbels E6

Array
Object Literals
Date
*/
var a = 25.5;
var fname = "navfal";
var isMaried = true;
var phone = null;//object
var b;//undefined

console.log(typeof b);

//ES6

const s1 = Symbol(); //random id unique
console.log(s1);

const s2 = Symbol(); //random id unique
console.log(s2);

console.log(s1 == s2);//false

var courses = ['c', 'c++', 'java'];
var student = {
    'name': 'navfal',
    'age': 25
}
var d = new Date();
console.log(d);
console.log(typeof d);

