//relational operator

/*
> greater then
< lesss then
>= greater then or equal to
<= lesss then or equal to
*/

let a = 10;
let b = 20;

console.log("Greater :", a > b);
console.log("lesser :", a < b);
console.log("Greater then equal:", a >= b);
console.log("lesser then equal :", a <= b);