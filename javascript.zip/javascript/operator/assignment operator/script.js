//assignment operator
let a = 10;

//a = a + 5;//+=
a += 5;
a -= 5;
a *= 5;
a /= 5;
a %= 5;

console.log(a);