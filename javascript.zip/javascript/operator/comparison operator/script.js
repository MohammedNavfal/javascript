//comparison

let a = 10;
let b = "25";
console.log(a == b);
console.log(a === b);
console.log(a != b);
