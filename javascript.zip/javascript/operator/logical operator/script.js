//logical

/*
&& logical and
|| logical or
! logical not
*/

//35-100
let mark = 20;
console.log(mark >= 35 && mark <= 100);

let a = 10;
//2,5
console.log(a == 2 || a == 5);

a = false;
console.log(!a);
