//arithmetic operation

let a = 100;
let b = 20;
let c;
c = a + b;
c = a - b
c = a - b
c = a / b;
c = a % b;
c = 2 ** 3;
c = ++a;
c = --b;


console.log(c);