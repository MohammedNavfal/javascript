//bitwise operator
